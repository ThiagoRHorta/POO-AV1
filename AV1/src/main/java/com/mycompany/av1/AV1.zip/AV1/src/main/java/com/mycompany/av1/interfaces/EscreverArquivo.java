package com.mycompany.av1.interfaces;

public interface EscreverArquivo {

    void salvar();

    void remover();
}
